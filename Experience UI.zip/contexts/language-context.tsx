"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { translations, type TranslationSet } from "@/lib/translations"
import type { Locale } from "date-fns"

type Language = "en" | "ar"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  toggleLanguage: () => void
  t: TranslationSet
  dateLocale: Locale
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en") // Default to English

  useEffect(() => {
    const storedLanguage = localStorage.getItem("appLanguage") as Language | null
    if (storedLanguage && (storedLanguage === "en" || storedLanguage === "ar")) {
      setLanguageState(storedLanguage)
    }
  }, [])

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang)
    localStorage.setItem("appLanguage", lang)
    document.documentElement.lang = lang
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"
  }, [])

  const toggleLanguage = useCallback(() => {
    setLanguage(language === "en" ? "ar" : "en")
  }, [language, setLanguage])

  useEffect(() => {
    document.documentElement.lang = language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
  }, [language])

  const t = translations[language]
  const dateLocale = translations[language].dateLocale

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t, dateLocale }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
