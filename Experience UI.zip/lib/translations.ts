import type { Locale } from "date-fns"
import { arSA, enUS } from "date-fns/locale"

export interface TranslationSet {
  pageTitle: string
  pageSubtitle: string
  destinationCountryLabel: string
  citizenshipLabel: string
  travelDateLabel: string
  searchCountryPlaceholder: string
  travelDatePlaceholder: string
  noCountriesFound: string
  errorDestination: string
  errorCitizenship: string
  errorTravelDate: string
  checkRequirementsButton: string
  searchingButton: string
  poweredBy: string
  languageToggle: string
  selectDate: string
  apiErrorDefault: string
  dateLocale: Locale
  home?: string // Added for header
  visaPrograms?: string // Added for header
  visaResultsTitle?: string
  visaResultsSubtitle?: string
  noVisaProgramsFound?: string
  visaProgram?: string
  processingTime?: string
  price?: string
  applyNow?: string
  learnMore?: string
  visaOrderFormTitle?: string
  visaOrderFormSubtitle?: string
  personalInformation?: string
  firstName?: string
  lastName?: string
  email?: string
  phoneNumber?: string
  passportInformation?: string
  passportNumber?: string
  passportExpiryDate?: string
  dateOfBirth?: string
  travelInformation?: string
  purposeOfTravel?: string
  additionalNotes?: string
  submitApplication?: string
  submittingApplication?: string
  visaConfirmationTitle?: string
  visaConfirmationMessage?: string
  backToHome?: string
  paymentConfirmationTitle?: string
  paymentConfirmationMessage?: string
  myOrders?: string
  orderId?: string
  status?: string
  orderDate?: string
  viewDetails?: string
  noOrdersFound?: string
}

export const translations: { [key: string]: TranslationSet } = {
  en: {
    pageTitle: "E-Visa Application Service",
    pageSubtitle: "Check your visa eligibility and apply online in minutes",
    destinationCountryLabel: "Destination Country",
    citizenshipLabel: "Your Citizenship",
    travelDateLabel: "Travel Date",
    searchCountryPlaceholder: "Search for a country...",
    travelDatePlaceholder: "When are you traveling?",
    noCountriesFound: "No countries found",
    errorDestination: "Please select a destination country",
    errorCitizenship: "Please select a citizenship country",
    errorTravelDate: "Please select a travel date",
    checkRequirementsButton: "Check Visa Requirements",
    searchingButton: "Searching...",
    poweredBy: "Powered by Omantel eVisa Services. Fast, secure, and reliable visa processing.",
    languageToggle: "العربية",
    selectDate: "When are you traveling?",
    apiErrorDefault: "Failed to process request",
    dateLocale: enUS,
    home: "Home",
    visaPrograms: "Visa Programs",
    visaResultsTitle: "Available Visa Programs",
    visaResultsSubtitle: "Based on your destination, citizenship, and travel date.",
    noVisaProgramsFound: "No visa programs found for your selection.",
    visaProgram: "Visa Program",
    processingTime: "Processing Time",
    price: "Price",
    applyNow: "Apply Now",
    learnMore: "Learn More",
    visaOrderFormTitle: "Visa Application Form",
    visaOrderFormSubtitle: "Please fill in your details accurately.",
    personalInformation: "Personal Information",
    firstName: "First Name",
    lastName: "Last Name",
    email: "Email Address",
    phoneNumber: "Phone Number",
    passportInformation: "Passport Information",
    passportNumber: "Passport Number",
    passportExpiryDate: "Passport Expiry Date",
    dateOfBirth: "Date of Birth",
    travelInformation: "Travel Information",
    purposeOfTravel: "Purpose of Travel",
    additionalNotes: "Additional Notes (Optional)",
    submitApplication: "Submit Application",
    submittingApplication: "Submitting...",
    visaConfirmationTitle: "Application Submitted!",
    visaConfirmationMessage:
      "Your visa application has been successfully submitted. We will notify you of any updates.",
    backToHome: "Back to Home",
    paymentConfirmationTitle: "Payment Successful!",
    paymentConfirmationMessage:
      "Your payment has been processed successfully. Your visa application is now being reviewed.",
    myOrders: "My Orders",
    orderId: "Order ID",
    status: "Status",
    orderDate: "Order Date",
    viewDetails: "View Details",
    noOrdersFound: "You have no visa orders yet.",
  },
  ar: {
    pageTitle: "خدمة طلب التأشيرة الإلكترونية",
    pageSubtitle: "تحقق من أهليتك للحصول على التأشيرة وقدم طلبك عبر الإنترنت في دقائق",
    destinationCountryLabel: "بلد الوجهة",
    citizenshipLabel: "جنسيتك",
    travelDateLabel: "تاريخ السفر",
    searchCountryPlaceholder: "ابحث عن بلد...",
    travelDatePlaceholder: "متى ستسافر؟",
    noCountriesFound: "لم يتم العثور على أي بلد",
    errorDestination: "يرجى اختيار بلد الوجهة",
    errorCitizenship: "يرجى اختيار بلد المواطنة",
    errorTravelDate: "يرجى اختيار تاريخ السفر",
    checkRequirementsButton: "تحقق من متطلبات التأشيرة",
    searchingButton: "جاري البحث...",
    poweredBy: "مدعوم من خدمات التأشيرات الإلكترونية لعمانتل. معالجة تأشيرات سريعة وآمنة وموثوقة.",
    languageToggle: "English",
    selectDate: "متى ستسافر؟",
    apiErrorDefault: "فشل في معالجة الطلب",
    dateLocale: arSA,
    home: "الرئيسية",
    visaPrograms: "برامج التأشيرات",
    visaResultsTitle: "برامج التأشيرات المتاحة",
    visaResultsSubtitle: "بناءً على وجهتك وجنسيتك وتاريخ سفرك.",
    noVisaProgramsFound: "لم يتم العثور على برامج تأشيرات لاختيارك.",
    visaProgram: "برنامج التأشيرة",
    processingTime: "وقت المعالجة",
    price: "السعر",
    applyNow: "قدم الآن",
    learnMore: "اعرف المزيد",
    visaOrderFormTitle: "نموذج طلب التأشيرة",
    visaOrderFormSubtitle: "يرجى ملء بياناتك بدقة.",
    personalInformation: "المعلومات الشخصية",
    firstName: "الاسم الأول",
    lastName: "اسم العائلة",
    email: "البريد الإلكتروني",
    phoneNumber: "رقم الهاتف",
    passportInformation: "معلومات جواز السفر",
    passportNumber: "رقم جواز السفر",
    passportExpiryDate: "تاريخ انتهاء صلاحية جواز السفر",
    dateOfBirth: "تاريخ الميلاد",
    travelInformation: "معلومات السفر",
    purposeOfTravel: "الغرض من السفر",
    additionalNotes: "ملاحظات إضافية (اختياري)",
    submitApplication: "إرسال الطلب",
    submittingApplication: "جاري الإرسال...",
    visaConfirmationTitle: "تم تقديم الطلب!",
    visaConfirmationMessage: "تم تقديم طلب التأشيرة الخاص بك بنجاح. سنقوم بإعلامك بأي تحديثات.",
    backToHome: "العودة إلى الرئيسية",
    paymentConfirmationTitle: "تم الدفع بنجاح!",
    paymentConfirmationMessage: "تمت معالجة دفعتك بنجاح. طلب التأشيرة الخاص بك قيد المراجعة الآن.",
    myOrders: "طلباتي",
    orderId: "رقم الطلب",
    status: "الحالة",
    orderDate: "تاريخ الطلب",
    viewDetails: "عرض التفاصيل",
    noOrdersFound: "ليس لديك طلبات تأشيرة حتى الآن.",
  },
}
