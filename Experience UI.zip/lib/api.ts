// Update API Base URL to use the staging URL instead of production
const API_BASE_URL = "https://stg-api.superjetom.com"

/**
 * Helper function to make API calls through our proxy
 */
async function callProxyApi(endpoint: string, body: any, authToken?: string | null) {
  const headers: HeadersInit = {
    "Content-Type": "application/json",
  }

  const callContext = `callProxyApi for ${endpoint}`

  if (authToken) {
    if (authToken.trim() === "") {
      console.warn(`${callContext}: Auth token is an empty string. Proceeding without Authorization header.`)
    } else {
      headers["Authorization"] = `Bearer ${authToken}`
      console.log(
        `${callContext}: Using auth token: Bearer ${authToken.substring(0, 10)}... (length: ${authToken.length})`,
      )
    }
  } else {
    console.log(`${callContext}: No auth token provided.`)
  }

  const response = await fetch(`/api/proxy?endpoint=${endpoint}`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  })

  let responseData
  try {
    responseData = await response.json()
  } catch (e) {
    const responseText = await response.text()
    console.error(
      `${callContext}: Failed to parse JSON response from proxy. Status: ${response.status}. Response text: ${responseText.substring(0, 500)}...`,
      e,
    )
    responseData = {
      error: "Proxy did not return valid JSON",
      details: responseText,
      status: response.status,
    }
  }

  if (!response.ok || responseData.error) {
    const errorTitle = responseData.error || `API Error (${response.status})`
    const errorDetails =
      typeof responseData.details === "string"
        ? responseData.details.substring(0, 500) + (responseData.details.length > 500 ? "..." : "")
        : JSON.stringify(responseData.details)

    console.error(
      `${callContext}: Proxy API call failed. Status: ${response.status}`,
      `Error Title: ${errorTitle}`,
      `Details: ${errorDetails}`,
      `Full Response Data (if available): ${JSON.stringify(responseData)}`,
    )

    const error = new Error(`${errorTitle}. Details: ${errorDetails}`)
    throw error
  }

  if (responseData.warning) {
    console.warn(`${callContext}: Proxy API call had a warning:`, responseData.warning, responseData.details)
  }

  return responseData
}

/**
 * Create an organization
 * @param organizationName The name of the organization
 * @returns Promise with the organization creation response, including vendor_key if successful
 */
export async function createOrganization(organizationName: string): Promise<{
  success: boolean
  data?: any
  vendor_key?: string | null
  error?: string
  _isMockData?: boolean
}> {
  console.log(`createOrganization: Attempting to create organization: ${organizationName}`)
  try {
    const responseData = await callProxyApi("create_organization", {
      organization_name: organizationName,
    })

    const vendorKey = responseData?.result?.[0]?.vendor_key
    if (vendorKey) {
      console.log(`createOrganization: Successfully received vendor key: ${vendorKey.substring(0, 10)}...`)
      localStorage.setItem("vendor_key", vendorKey)
      console.log("createOrganization: Vendor key stored in localStorage.")
      return {
        success: true,
        data: responseData,
        vendor_key: vendorKey,
      }
    } else {
      console.error("createOrganization: No vendor key found in response.", responseData)
      return {
        success: false,
        error:
          "No vendor key found in create_organization response. API Response: " +
          JSON.stringify(responseData).substring(0, 100),
        // data: responseData, // Keep if frontend needs raw response on this specific error
      }
    }
  } catch (error) {
    console.error("createOrganization: Failed to create organization.", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to create organization (unknown error)",
      // data: undefined, // Explicitly no data on error
    }
  }
}

/**
 * Login a traveller
 * @param credentials The traveller's credentials
 * @returns Promise with the login response
 */
export async function loginTraveller(credentials: any): Promise<any> {
  try {
    return { success: true, token: "mock_token" }
  } catch (error) {
    return { success: false, message: "Invalid credentials" }
  }
}

/**
 * Create a traveller
 * @param travellerData The traveller's data
 * @returns Promise with the traveller creation response
 */
export async function createTraveller(travellerData: any): Promise<any> {
  try {
    return { success: true, message: "Traveller created successfully" }
  } catch (error) {
    return { success: false, message: "Failed to create traveller" }
  }
}

/**
 * Create a traveller Omantel
 * @param userData The traveller's data
 * @returns Promise with the traveller creation response
 */
export async function createTravellerOmantel(userData: {
  email: string
  first_name: string
  last_name: string
  locale: string
}): Promise<any> {
  try {
    const vendorKey = await ensureVendorKey() // This vendorKey is for Authorization header
    console.log(`createTravellerOmantel: Using vendorKey: ${vendorKey.substring(0, 10)}... as Auth token.`)

    // Body does NOT contain vendor_key as per user's spec for this call
    const requestBody = {
      email: userData.email,
      first_name: userData.first_name,
      last_name: userData.last_name,
      locale: userData.locale,
    }

    const data = await callProxyApi("create_traveller_omantel", requestBody, vendorKey) // vendorKey for Auth header
    console.log("createTravellerOmantel: API response data:", JSON.stringify(data, null, 2))

    const travellerToken = data?.result?.[0]?.access_token
    if (travellerToken) {
      localStorage.setItem("traveller_access_token", travellerToken)
      console.log(`createTravellerOmantel: Traveller access token stored: ${travellerToken.substring(0, 10)}...`)
    } else {
      console.warn("createTravellerOmantel: No access_token found in response.")
    }
    return data
  } catch (error) {
    console.error("createTravellerOmantel: Failed.", error)
    if (
      process.env.NODE_ENV !== "production" ||
      (typeof window !== "undefined" && window.location.hostname.includes("localhost"))
    ) {
      console.warn("createTravellerOmantel: Using mock data due to error.")
      return {
        success: false, // Indicate failure
        error: `Mock Fallback: ${error instanceof Error ? error.message : "Unknown error during traveller creation (Omantel)"}`,
        _isMockData: true,
        // Optionally, provide some minimal mock data if needed by frontend error handling
        // result: [/* ... */],
      }
    }
    throw error
  }
}

/**
 * Create an iframe order for visa Omantel
 * @param orderData The order data
 * @returns Promise with the iframe order response
 */
export async function createIframeOrderVisaOmantel(orderData: {
  vendor_key: string
  reference_no: string
  description: string
  program_id: string
  quantity: number
  first_name: string
  last_name: string
  email: string
  fee: string
  arrival: string
  destination: string
  commision?: string
  commision_type?: string
}): Promise<any> {
  try {
    const accessToken = localStorage.getItem("traveller_access_token")
    if (!accessToken || accessToken.trim() === "") {
      console.error("createIframeOrderVisaOmantel: No valid traveller access token found for Authorization header.")
      throw new Error("No valid traveller access token found. Please ensure traveller is created/logged in first.")
    }
    console.log(
      `createIframeOrderVisaOmantel: Using traveller_access_token (for Auth header): ${accessToken.substring(0, 10)}...`,
    )

    const requestBody = { ...orderData }
    console.log("createIframeOrderVisaOmantel: Calling API with body:", JSON.stringify(requestBody, null, 2))

    const data = await callProxyApi("iframe_order_visa_omantel", requestBody, accessToken)
    console.log("createIframeOrderVisaOmantel: API response data:", JSON.stringify(data, null, 2))

    if (data?.result?.iframe_deeplink_url) {
      localStorage.setItem("iframe_url", data.result.iframe_deeplink_url)
      sessionStorage.setItem("iframe_url", data.result.iframe_deeplink_url)
      localStorage.setItem("iframe_url_timestamp", new Date().toISOString())
      console.log("createIframeOrderVisaOmantel: Iframe URL stored.")
    } else {
      const errorDetails = data.error || data.details || "Missing iframe_deeplink_url and no specific API error."
      console.error("createIframeOrderVisaOmantel: No iframe_deeplink_url in response.", data)
      throw new Error(`Backend issue: ${errorDetails}`)
    }

    if (data?.result?.order_id) {
      localStorage.setItem("order_id", data.result.order_id)
      console.log("createIframeOrderVisaOmantel: Order ID stored.")
    }
    return data
  } catch (error) {
    console.error("createIframeOrderVisaOmantel: Failed.", error)
    const errorMsg = error instanceof Error ? error.message : "Unknown error during iframe order creation."
    if (
      process.env.NODE_ENV !== "production" ||
      (typeof window !== "undefined" && window.location.hostname.includes("localhost"))
    ) {
      console.warn("createIframeOrderVisaOmantel: Using mock data due to error.")
      const mockIframeUrl = "https://omantel.sandbox-simplevisa.net/iframe/mock-order-error-fallback"
      const mockOrderId = `order_mock_iframe_${Math.random().toString(36).substring(2, 10)}`
      localStorage.setItem("iframe_url", mockIframeUrl)
      sessionStorage.setItem("iframe_url", mockIframeUrl)
      localStorage.setItem("order_id", mockOrderId)
      localStorage.setItem("iframe_url_timestamp", new Date().toISOString())
      return {
        success: false, // Indicate failure
        error: `Mock Fallback: ${errorMsg}`, // Prepend to clarify it's a mock error
        // Optionally, you can still provide some mock structure if the frontend expects it on error
        // For example, if the frontend tries to read iframe_url even on error:
        // result: { iframe_deeplink_url: mockIframeUrl, order_id: mockOrderId, reference_no: orderData.reference_no },
        // However, it's cleaner to have the frontend handle the error state without expecting partial data.
        // For now, let's keep it simple:
        _isMockData: true, // Keep this if you want to identify mock responses
      }
    }
    throw error
  }
}

/**
 * Get visa programs
 * @param params The parameters for the API call (destination, citizenship, arrivalDate)
 * @returns Promise with an object: { success: boolean, data?: VisaProgram[], error?: string }
 */
export async function getVisaPrograms(params: {
  destination: string
  citizenship: string
  arrivalDate: string
}): Promise<{ success: boolean; data?: any[]; error?: string }> {
  try {
    const vendorKey = await ensureVendorKey()
    console.log(`getVisaPrograms: Using vendorKey for API call.`)

    const requestBody = {
      destination: params.destination.toLowerCase(),
      citizenship: params.citizenship.toLowerCase(),
      arrivalDate: params.arrivalDate, // Ensure this is in DD-MM-YYYY if API requires
    }

    console.log("getVisaPrograms: Calling get_visa_programs_omantel with body:", requestBody)
    const rawResponseData = await callProxyApi("get_visa_programs_omantel", requestBody, vendorKey)

    // Store raw response for debugging or potential caching
    localStorage.setItem("visa_programs_data_raw", JSON.stringify(rawResponseData))
    console.log("getVisaPrograms: Raw API response data:", JSON.stringify(rawResponseData, null, 2))

    if (rawResponseData.warning && rawResponseData.responseText) {
      console.warn("getVisaPrograms: Received warning from proxy:", rawResponseData.warning, rawResponseData.details)
      // Decide if this warning constitutes an error or if data might still be usable
      // For now, let's assume data might still be there.
    }

    let rawProgramsArray: any[] = []

    // Extract programs array from various possible locations in the response
    if (rawResponseData?.result?.programs && Array.isArray(rawResponseData.result.programs)) {
      rawProgramsArray = rawResponseData.result.programs
    } else if (rawResponseData?.result && Array.isArray(rawResponseData.result)) {
      // This case might occur if 'result' itself is the array of programs
      rawProgramsArray = rawResponseData.result
    } else if (rawResponseData?.programs && Array.isArray(rawResponseData.programs)) {
      rawProgramsArray = rawResponseData.programs
    } else if (
      rawResponseData?.result &&
      typeof rawResponseData.result === "object" &&
      !Array.isArray(rawResponseData.result)
    ) {
      // Handle cases where programs are values in an object, e.g. { "0": {...}, "1": {...} }
      // This was a previous attempt, ensure it's still relevant or simplify if not.
      const programsFromObject = Object.values(rawResponseData.result).filter(
        (item: any) => typeof item === "object" && item !== null && item.id,
      )
      if (programsFromObject.length > 0) {
        rawProgramsArray = programsFromObject
      }
    }

    if (rawProgramsArray.length === 0 && !rawResponseData.warning) {
      // If no programs and no specific warning, it might be an issue.
      console.warn("getVisaPrograms: No programs found in the expected locations of the response.", rawResponseData)
      // Do not return error yet, let frontend decide based on empty array.
    }

    // Transform rawProgramsArray to VisaProgram[] structure
    const transformedPrograms = rawProgramsArray.map((rawProgram: any) => {
      // Basic transformation, adjust according to actual rawProgram structure and VisaProgram interface
      let descriptionText = "No description available."
      const rawDesc = rawProgram.description || rawProgram.notes || rawProgram.additional_info
      if (typeof rawDesc === "string") {
        descriptionText = rawDesc
      } else if (typeof rawDesc === "object" && rawDesc !== null && typeof rawDesc.body === "string") {
        descriptionText = rawDesc.body
      } else if (typeof rawDesc === "object" && rawDesc !== null) {
        // Fallback if it's an object but no 'body', try to stringify or provide a generic message
        console.warn("Program description is an object without a 'body' string property:", rawDesc)
        descriptionText = "Description format unclear, see console."
      }

      return {
        id: rawProgram.id || `fallback-id-${Math.random().toString(36).substring(2, 9)}`,
        name: rawProgram.program_name || rawProgram.name || "Unnamed Visa Program",
        description: descriptionText,
        price: Number.parseFloat(rawProgram.fee || "0"), // Ensure price is a number
        currency: rawProgram.currency_code || "USD", // Default currency
        processingTime: rawProgram.suggested_processing_time || rawProgram.processing_time || "Not specified",
        imageUrl: rawProgram.image_url || null, // API might provide an image_url
        countryCode: rawProgram.country_code_for_flag || rawProgram.destination_country_code || null, // For flag generation
        requirements: rawProgram.requirements || [], // Assuming requirements is an array
        eligibility: rawProgram.eligibility || {},
        category: rawProgram.program_type || rawProgram.category || "General",
        embassyLink: rawProgram.embassy_info || rawProgram.embassy_link || null,
        // Add other fields from VisaProgram interface as needed
        max_stay: rawProgram.max_stay,
        validity: rawProgram.validity,
        max_entries: rawProgram.max_entries,
        available: rawProgram.available !== undefined ? rawProgram.available : true, // Default to true if not specified
      }
    })

    return { success: true, data: transformedPrograms }
  } catch (error) {
    console.error("getVisaPrograms: Failed to fetch or process visa programs.", error)
    // Attempt to get a more specific error message
    let errorMessage = "Failed to fetch visa programs. Please try again."
    if (error instanceof Error) {
      errorMessage = error.message
    } else if (typeof error === "string") {
      errorMessage = error
    } else if (typeof error === "object" && error !== null && "details" in error) {
      errorMessage = String((error as any).details)
    }

    // Fallback to cached data is removed for simplification, can be added back if needed.
    // const cachedDataString = localStorage.getItem("visa_programs_data_raw");
    // if (cachedDataString) { ... }

    return {
      success: false,
      error: errorMessage,
    }
  }
}

/**
 * Get countries
 * @returns Promise with the countries response
 */
export async function getCountries(): Promise<any> {
  try {
    const vendorKey = await ensureVendorKey()
    console.log(`getCountries: Using vendorKey: ${vendorKey.substring(0, 10)}... for API call.`)
    const response = await callProxyApi("country", { vendor_key: vendorKey })
    return { countries: response.result || [], _isMockData: false }
  } catch (error) {
    console.error("getCountries: Error fetching countries.", error)
    return {
      countries: [],
      _isMockData: true,
      error: error instanceof Error ? error.message : "Unknown error fetching countries",
    }
  }
}

/**
 * Check if the API is in offline mode
 * @returns boolean indicating offline mode
 */
export function isOfflineMode(): boolean {
  return false
}

/**
 * Set the API to offline mode
 * @param isOffline boolean indicating whether to set to offline mode
 */
export function setOfflineMode(isOffline: boolean): void {
  console.warn("setOfflineMode is a stub.")
}

/**
 * Initialize the API
 * @returns Promise indicating whether initialization was successful
 */
export async function initializeApi(): Promise<boolean> {
  try {
    await ensureVendorKey()
    console.log("API Initialized (vendor key ensured).")
    return true
  } catch (e) {
    console.error("API initialization (ensureVendorKey) failed:", e)
    return false
  }
}

/**
 * Check if the API is initialized
 * @returns boolean indicating whether the API is initialized
 */
export function isApiInitialized(): boolean {
  return !!localStorage.getItem("vendor_key")
}

/**
 * Generate a reference number
 * @returns A generated reference number
 */
export function generateReferenceNumber(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let result = ""
  for (let i = 0; i < 15; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

/**
 * Ensure a vendor key is present.
 * This function is now EXPORTED.
 * @returns Promise with the vendor key
 */
export async function ensureVendorKey(): Promise<string> {
  let vendorKey = localStorage.getItem("vendor_key")
  if (vendorKey) {
    console.log(`ensureVendorKey: Found vendor key in localStorage: ${vendorKey.substring(0, 10)}...`)
    return vendorKey
  }

  console.log("ensureVendorKey: No vendor key in localStorage. Attempting to create new organization...")
  const orgName = "Omantel_AutoOrg_" + Date.now()
  const orgResponse = await createOrganization(orgName)

  if (orgResponse.success && orgResponse.vendor_key) {
    vendorKey = orgResponse.vendor_key
    console.log(`ensureVendorKey: New vendor key generated and stored: ${vendorKey.substring(0, 10)}...`)
    return vendorKey
  } else {
    const errorMsg = `ensureVendorKey: Failed to obtain vendor key. Org creation error: ${orgResponse.error || "Unknown organization creation failure."}`
    console.error(errorMsg, orgResponse)
    throw new Error(errorMsg)
  }
}
