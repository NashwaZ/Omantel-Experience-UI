// Ensure this file is exactly as previously defined, especially the "USA" entry.
// Example "USA" entry:
// {
//   destination: "USA",
//   requiredDocuments: ["Passport Photo"],
//   additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
// },

export interface DestinationRequirement {
  destination: string
  requiredDocuments: string[]
  additionalInformation: string
}

export const destinationRequirements: DestinationRequirement[] = [
  {
    destination: "Australia",
    requiredDocuments: ["Passport Photo", "Portrait Photo (for ETA, 3 different)"],
    additionalInformation:
      "Passport must have 6 months validity left from entry before its expiration date. For ETA, three different portrait photos need to be taken one after another, without smiling. Additional documents may be requested in some cases, determined by the authorities or place of birth.",
  },
  {
    destination: "Azerbaijan",
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "Passport must have 3 months validity from visa expiry.",
  },
  {
    destination: "Cambodia",
    requiredDocuments: ["Passport Photo", "Portrait Photo (JPEG/JPG/PNG)"],
    additionalInformation:
      "Passport must have 6 months validity left from entry before its expiration date. Optional: Return ticket, Letter of Invitation, Hotel Reservation.",
  },
  {
    destination: "Canada",
    requiredDocuments: [],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Cuba",
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "",
  },
  {
    destination: "Egypt",
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Ethiopia",
    requiredDocuments: ["Passport Photo", "Portrait Photo"],
    additionalInformation: "Portrait photo should be recent, good quality, and not older than 6 months.",
  },
  {
    destination: "India",
    requiredDocuments: ["Passport Photo", "Portrait Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Indonesia",
    requiredDocuments: ["Passport Photo (JPG)", "Portrait Photo", "Passport Scan (PDF)", "Return Ticket (PDF)"],
    additionalInformation:
      "Return Ticket must be in PDF format (no screenshots allowed). Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Ivory Coast",
    requiredDocuments: ["Passport Photo", "Return Ticket", "Hotel Reservation/Invitation Letter"],
    additionalInformation:
      "All documents must be in JPG/PNG/GIF/PDF format, and each file should be ≤ 1 Mb. Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Jordan",
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "Passport details will be required.",
  },
  {
    destination: "Kenya",
    requiredDocuments: ["Passport Photo", "Portrait Photo", "Accommodation Booking", "Return Ticket"],
    additionalInformation:
      "Passport must have 6 months validity left from entry before its expiration date. In cases where the host is a resident of Kenya, an invitation letter and host ID are required.",
  },
  {
    destination: "Korea",
    requiredDocuments: ["Portrait Photo"],
    additionalInformation: "",
  },
  {
    destination: "Kuwait",
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Laos",
    requiredDocuments: ["Passport Photo", "Portrait Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Madagascar",
    requiredDocuments: [],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Myanmar",
    requiredDocuments: ["Passport Photo", "Portrait Photo", "Return Ticket", "Hotel Booking Confirmation"],
    additionalInformation:
      "Only passports will be eligible for e-visa; travel documents will not be accepted. Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Malaysia",
    requiredDocuments: [
      "Portrait Photo",
      "Round Trip Flight Ticket",
      "Accommodation Documents",
      "Bank Statement (last 3 months)",
    ],
    additionalInformation: "Portrait photo should be recent, good quality, and not older than 6 months.",
  },
  {
    destination: "New Zealand",
    requiredDocuments: ["Portrait Photo"],
    additionalInformation:
      "Portrait photo should be recent, good quality, and not older than 6 months. Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Oman",
    requiredDocuments: ["Passport Photo", "Portrait Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Pakistan",
    requiredDocuments: ["Passport Photo", "Portrait Photo", "Letter by Sponsor/Hotel/Tour Operator"],
    additionalInformation:
      "Portrait photo should be recent, good quality, and not older than 6 months. Passport must have 6 months validity left from entry. Mandatory Parent Consent Form for visa applications of children under 18 years of age bearing passports of USA, UK, and Australia (both parents must provide consent, or a single parent if they are the sole custodian as per legal papers).",
  },
  {
    destination: "Russia",
    requiredDocuments: ["Portrait Photo"],
    additionalInformation: "Portrait photo should be recent, good quality, and not older than 6 months.",
  },
  {
    destination: "Saudi Arabia",
    requiredDocuments: ["Portrait Photo"],
    additionalInformation: "Portrait photo should be recent, good quality, and not older than 6 months.",
  },
  {
    destination: "Singapore",
    requiredDocuments: [],
    additionalInformation: "",
  },
  {
    destination: "Sri Lanka",
    requiredDocuments: [],
    additionalInformation: "",
  },
  {
    destination: "Tanzania",
    requiredDocuments: ["Portrait Photo", "Passport Photo", "Return Ticket"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Thailand",
    requiredDocuments: [
      "Passport Photo",
      "Portrait Photo",
      "Travel Booking Confirmation",
      "Proof of Accommodation",
      "Financial Evidence (min 20,000 THB)",
      "Document of Current Residency",
    ],
    additionalInformation:
      "Portrait photo should be recent, good quality, and not older than 6 months. Passport/travel document must be valid for at least six months from the date of visa application for single entry and one year for multiple entries.",
  },
  {
    destination: "Turkey",
    requiredDocuments: [],
    additionalInformation: "",
  },
  {
    destination: "United States", // This is the key entry
    requiredDocuments: ["Passport Photo"],
    additionalInformation: "Passport must have 6 months validity left from entry before its expiration date.",
  },
  {
    destination: "Vietnam",
    requiredDocuments: ["Passport Photo", "Portrait Photo"],
    additionalInformation:
      "Portrait photo should be recent, good quality, and not older than 6 months. Passport must have 6 months validity left from entry before its expiration date.",
  },
]

export function getDestinationRequirements(destination: string): DestinationRequirement | undefined {
  if (!destination) return undefined // Guard against undefined or null destination string
  return destinationRequirements.find((req) => req.destination.toLowerCase() === destination.toLowerCase())
}
