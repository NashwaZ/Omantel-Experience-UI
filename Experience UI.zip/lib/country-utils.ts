// Country code mapping for flags and other country-related utilities
import { allCountries } from "./countries"

// ISO 3166-1 alpha-2 country codes mapping
export const countryToISOCode: Record<string, string> = {
  Afghanistan: "af",
  Albania: "al",
  Algeria: "dz",
  Andorra: "ad",
  Angola: "ao",
  "Antigua and Barbuda": "ag",
  Argentina: "ar",
  Armenia: "am",
  Australia: "au",
  Austria: "at",
  Azerbaijan: "az",
  Bahamas: "bs",
  Bahrain: "bh",
  Bangladesh: "bd",
  Barbados: "bb",
  Belarus: "by",
  Belgium: "be",
  Belize: "bz",
  Benin: "bj",
  Bhutan: "bt",
  Bolivia: "bo",
  "Bosnia and Herzegovina": "ba",
  Botswana: "bw",
  Brazil: "br",
  Brunei: "bn",
  Bulgaria: "bg",
  "Burkina Faso": "bf",
  Burundi: "bi",
  "Cabo Verde": "cv",
  Cambodia: "kh",
  Cameroon: "cm",
  Canada: "ca",
  "Central African Republic": "cf",
  Chad: "td",
  Chile: "cl",
  China: "cn",
  Colombia: "co",
  Comoros: "km",
  "Congo (Congo-Brazzaville)": "cg",
  "Costa Rica": "cr",
  Croatia: "hr",
  Cuba: "cu",
  Cyprus: "cy",
  "Czech Republic": "cz",
  "Democratic Republic of the Congo": "cd",
  Denmark: "dk",
  Djibouti: "dj",
  Dominica: "dm",
  "Dominican Republic": "do",
  Ecuador: "ec",
  Egypt: "eg",
  "El Salvador": "sv",
  "Equatorial Guinea": "gq",
  Eritrea: "er",
  Estonia: "ee",
  Eswatini: "sz",
  Ethiopia: "et",
  Fiji: "fj",
  Finland: "fi",
  France: "fr",
  Gabon: "ga",
  Gambia: "gm",
  Georgia: "ge",
  Germany: "de",
  Ghana: "gh",
  Greece: "gr",
  Grenada: "gd",
  Guatemala: "gt",
  Guinea: "gn",
  "Guinea-Bissau": "gw",
  Guyana: "gy",
  Haiti: "ht",
  "Holy See (Vatican City)": "va",
  Honduras: "hn",
  Hungary: "hu",
  Iceland: "is",
  India: "in",
  Indonesia: "id",
  Iran: "ir",
  Iraq: "iq",
  Ireland: "ie",
  Israel: "il",
  Italy: "it",
  "Ivory Coast": "ci",
  Jamaica: "jm",
  Japan: "jp",
  Jordan: "jo",
  Kazakhstan: "kz",
  Kenya: "ke",
  Kiribati: "ki",
  Kosovo: "xk", // Not officially ISO 3166-1, but commonly used
  Kuwait: "kw",
  Kyrgyzstan: "kg",
  Laos: "la",
  Latvia: "lv",
  Lebanon: "lb",
  Lesotho: "ls",
  Liberia: "lr",
  Libya: "ly",
  Liechtenstein: "li",
  Lithuania: "lt",
  Luxembourg: "lu",
  Madagascar: "mg",
  Malawi: "mw",
  Malaysia: "my",
  Maldives: "mv",
  Mali: "ml",
  Malta: "mt",
  "Marshall Islands": "mh",
  Mauritania: "mr",
  Mauritius: "mu",
  Mexico: "mx",
  Micronesia: "fm",
  Moldova: "md",
  Monaco: "mc",
  Mongolia: "mn",
  Montenegro: "me",
  Morocco: "ma",
  Mozambique: "mz",
  "Myanmar (Burma)": "mm",
  Namibia: "na",
  Nauru: "nr",
  Nepal: "np",
  Netherlands: "nl",
  "New Zealand": "nz",
  Nicaragua: "ni",
  Niger: "ne",
  Nigeria: "ng",
  "North Korea": "kp",
  "North Macedonia": "mk",
  Norway: "no",
  Oman: "om",
  Pakistan: "pk",
  Palau: "pw",
  Palestine: "ps",
  Panama: "pa",
  "Papua New Guinea": "pg",
  Paraguay: "py",
  Peru: "pe",
  Philippines: "ph",
  Poland: "pl",
  Portugal: "pt",
  Qatar: "qa",
  Romania: "ro",
  Russia: "ru",
  Rwanda: "rw",
  "Saint Kitts and Nevis": "kn",
  "Saint Lucia": "lc",
  "Saint Vincent and the Grenadines": "vc",
  Samoa: "ws",
  "San Marino": "sm",
  "Sao Tome and Principe": "st",
  "Saudi Arabia": "sa",
  Senegal: "sn",
  Serbia: "rs",
  Seychelles: "sc",
  "Sierra Leone": "sl",
  Singapore: "sg",
  Slovakia: "sk",
  Slovenia: "si",
  "Solomon Islands": "sb",
  Somalia: "so",
  "South Africa": "za",
  "South Korea": "kr",
  "South Sudan": "ss",
  Spain: "es",
  "Sri Lanka": "lk",
  Sudan: "sd",
  Suriname: "sr",
  Sweden: "se",
  Switzerland: "ch",
  Syria: "sy",
  Taiwan: "tw",
  Tajikistan: "tj",
  Tanzania: "tz",
  Thailand: "th",
  "Timor-Leste": "tl",
  Togo: "tg",
  Tonga: "to",
  "Trinidad and Tobago": "tt",
  Tunisia: "tn",
  Turkey: "tr",
  Turkmenistan: "tm",
  Tuvalu: "tv",
  Uganda: "ug",
  Ukraine: "ua",
  "United Arab Emirates": "ae",
  "United Kingdom": "gb",
  "United States": "us",
  Uruguay: "uy",
  Uzbekistan: "uz",
  Vanuatu: "vu",
  Venezuela: "ve",
  Vietnam: "vn",
  Yemen: "ye",
  Zambia: "zm",
  Zimbabwe: "zw",
  // Additional territories and dependencies
  "American Samoa": "as",
  Anguilla: "ai",
  Aruba: "aw",
  Bermuda: "bm",
  "British Virgin Islands": "vg",
  "Cayman Islands": "ky",
  "Cook Islands": "ck",
  Curaçao: "cw",
  "Falkland Islands": "fk",
  "Faroe Islands": "fo",
  "French Polynesia": "pf",
  Gibraltar: "gi",
  Greenland: "gl",
  Guam: "gu",
  Guernsey: "gg",
  "Hong Kong": "hk",
  "Isle of Man": "im",
  Jersey: "je",
  Macau: "mo",
  Montserrat: "ms",
  "New Caledonia": "nc",
  Niue: "nu",
  "Northern Mariana Islands": "mp",
  "Puerto Rico": "pr",
  "Saint Barthélemy": "bl",
  "Saint Helena, Ascension and Tristan da Cunha": "sh",
  "Saint Martin": "mf",
  "Saint Pierre and Miquelon": "pm",
  "Sint Maarten": "sx",
  Tokelau: "tk",
  "Turks and Caicos Islands": "tc",
  "U.S. Virgin Islands": "vi",
  "Wallis and Futuna": "wf",
  "Western Sahara": "eh",
}

/**
 * Get the country flag URL for a given country name or ISO code.
 * @param countryNameOrCode The name of the country or its 2-letter ISO code.
 * @param size The desired width of the flag image (e.g., "64", "128", "256"). Defaults to "64".
 * @returns URL to the country flag image or a placeholder.
 */
export function getCountryFlagUrl(countryNameOrCode: string, size = "64"): string {
  let isoCode: string | undefined = undefined

  if (!countryNameOrCode || typeof countryNameOrCode !== "string" || countryNameOrCode.trim() === "") {
    console.warn(
      `getCountryFlagUrl: Received invalid or empty countryNameOrCode ('${countryNameOrCode}'). Returning placeholder.`,
    )
    return `/placeholder.svg?height=${size}&width=${size}&query=unknown%20flag`
  }

  const trimmedInput = countryNameOrCode.trim()

  // Check if it's already a 2-letter ISO code (case-insensitive)
  if (trimmedInput.length === 2 && /^[a-zA-Z]+$/.test(trimmedInput)) {
    isoCode = trimmedInput.toUpperCase()
    console.log(`getCountryFlagUrl: Interpreted '${trimmedInput}' as ISO code '${isoCode}'.`)
  } else {
    // Try to get the ISO code from our mapping using the country name (case-insensitive lookup)
    const normalizedInput = trimmedInput.toLowerCase()
    const foundEntry = Object.entries(countryToISOCode).find(([name]) => name.toLowerCase() === normalizedInput)

    if (foundEntry) {
      isoCode = foundEntry[1].toUpperCase() // The code from the map should already be uppercase, but ensure it.
      console.log(`getCountryFlagUrl: Mapped country name '${trimmedInput}' to ISO code '${isoCode}'.`)
    } else {
      console.warn(
        `getCountryFlagUrl: Could not map country name '${trimmedInput}' to an ISO code. It's not a 2-letter code either. Returning placeholder.`,
      )
    }
  }

  if (isoCode) {
    // Ensure isoCode is indeed 2 letters and uppercase before using in URL
    if (isoCode.length === 2 && isoCode === isoCode.toUpperCase()) {
      return `https://flagsapi.com/${isoCode}/flat/${size}.png`
    } else {
      console.warn(
        `getCountryFlagUrl: Derived isoCode '${isoCode}' is not a valid 2-letter uppercase code. Returning placeholder.`,
      )
    }
  }

  // Fallback if isoCode could not be determined or was invalid
  console.warn(`getCountryFlagUrl: Fallback to placeholder for input '${trimmedInput}'.`)
  return `/placeholder.svg?height=${size}&width=${size}&query=flag%20of%20${encodeURIComponent(trimmedInput)}`
}

/**
 * Check if a country name is valid
 * @param countryName The name of the country to check
 * @returns boolean indicating if the country is valid
 */
export function isValidCountry(countryName: string): boolean {
  return allCountries.includes(countryName)
}
