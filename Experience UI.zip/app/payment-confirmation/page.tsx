"use client"

import { useEffect, useState } from "react"
import LoadingIndicator from "@/components/loading-indicator"

export default function PaymentConfirmation() {
  const [iframeUrl, setIframeUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [debugInfo, setDebugInfo] = useState<{
    iframeUrl?: string
    timestamp?: string
    orderId?: string
  }>({})

  useEffect(() => {
    // Get the iframe URL from localStorage
    const storedIframeUrl = localStorage.getItem("iframe_url")

    if (storedIframeUrl) {
      setIframeUrl(storedIframeUrl)
    } else {
      console.error("No iframe URL found in localStorage")
    }

    setIsLoading(false)
  }, [])

  useEffect(() => {
    // Only in development or when debugging
    if (process.env.NODE_ENV !== "production" || localStorage.getItem("debug_mode") === "true") {
      setDebugInfo({
        iframeUrl: localStorage.getItem("iframe_url") || sessionStorage.getItem("iframe_url") || "Not found",
        timestamp: localStorage.getItem("iframe_url_timestamp") || "Not recorded",
        orderId: localStorage.getItem("order_id") || "Not found",
      })
    }
  }, [])

  // Full-screen loading indicator
  if (isLoading) {
    return <LoadingIndicator fullScreen text="Loading payment gateway..." />
  }

  // If no iframe URL is found, show an error
  if (!iframeUrl) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-white">
        <div className="text-center p-4">
          <p className="text-red-600 mb-2">Payment gateway not available</p>
          <p className="text-gray-600">Please try again later.</p>
        </div>
      </div>
    )
  }

  // Full-screen iframe with no other content
  return (
    <div className="fixed inset-0 w-full h-full">
      <iframe
        src={iframeUrl}
        className="w-full h-full border-0"
        frameBorder="0"
        title="Payment Gateway"
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
      ></iframe>
      {(process.env.NODE_ENV !== "production" || localStorage.getItem("debug_mode") === "true") && (
        <div className="mt-8 p-4 border border-gray-200 rounded-lg bg-gray-50 text-xs">
          <h3 className="font-bold mb-2">Debug Information (Development Only)</h3>
          <div className="space-y-1">
            <p>
              <span className="font-semibold">Iframe URL:</span> {debugInfo.iframeUrl}
            </p>
            <p>
              <span className="font-semibold">Timestamp:</span> {debugInfo.timestamp}
            </p>
            <p>
              <span className="font-semibold">Order ID:</span> {debugInfo.orderId}
            </p>
          </div>
          <button
            onClick={() => {
              localStorage.setItem("debug_mode", "false")
              setDebugInfo({})
            }}
            className="mt-2 px-2 py-1 bg-gray-200 rounded text-xs"
          >
            Hide Debug Info
          </button>
        </div>
      )}
    </div>
  )
}
