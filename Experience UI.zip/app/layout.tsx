import type React from "react"
import ClientRootLayout from "./client"

export const metadata = {
  title: "Visa Application Service",
  description: "Apply for visas online with ease",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <ClientRootLayout>{children}</ClientRootLayout>
}


import './globals.css'