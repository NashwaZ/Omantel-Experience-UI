"use client"

import type React from "react"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import ApiInitializer from "@/components/api-initializer"
import ApiStorageManager from "@/components/api-storage-manager"
import ApiDebugPanel from "@/components/api-debug-panel"
import { LanguageProvider, useLanguage } from "@/contexts/language-context" // Import LanguageProvider
import Header from "@/components/header" // Import Header
import Footer from "@/components/footer" // Import Footer
import { Inter, Albert_Sans } from "next/font/google"
import { useEffect } from "react"

// Use Inter font from Google Fonts as primary font
const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
})

// Use Albert Sans as secondary font
const albertSans = Albert_Sans({
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-albert-sans",
})

// This component is necessary to use the useLanguage hook for setting html attributes
function HtmlAttributesSetter() {
  const { language } = useLanguage() // This will run client-side after hydration
  useEffect(() => {
    document.documentElement.lang = language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
  }, [language])
  return null
}

export default function ClientRootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="theme-color" content="#ea6e00" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
      </head>
      <body
        className={`${inter.variable} ${albertSans.variable} font-sans font-normal text-base leading-normal text-foreground bg-background`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <LanguageProvider>
            {" "}
            {/* Wrap with LanguageProvider */}
            <HtmlAttributesSetter /> {/* Component to set html lang/dir client-side */}
            <ApiInitializer />
            <div className="flex flex-col min-h-screen">
              <Header /> {/* Add Header here */}
              <main className="flex-grow">{children}</main>
              <Footer /> {/* Add Footer here */}
            </div>
            <ApiStorageManager />
            <ApiDebugPanel />
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
