// The base URL for the external API
const API_BASE_URL = "https://stg-api.superjetom.com"

export async function POST(req: Request) {
  const { searchParams } = new URL(req.url)
  const endpoint = searchParams.get("endpoint")

  if (!endpoint) {
    return new Response(JSON.stringify({ error: "Endpoint parameter is required" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    })
  }

  try {
    const body = await req.json() // Assuming incoming request to proxy is always JSON

    const authHeader = req.headers.get("Authorization")
    console.log(
      `Proxy: Forwarding request to ${endpoint} with auth: ${authHeader ? "Bearer " + authHeader.substring(0, 15) + "..." : "none"}`,
    )

    const headers: HeadersInit = {
      "Content-Type": "application/json",
      Accept: "application/json", // Explicitly request JSON response
    }

    if (authHeader) {
      headers["Authorization"] = authHeader
    }

    const apiResponse = await fetch(`${API_BASE_URL}/${endpoint}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    })

    const responseContentType = apiResponse.headers.get("Content-Type")
    console.log(
      `Proxy: Response from ${API_BASE_URL}/${endpoint} - Status: ${apiResponse.status}, Content-Type: ${responseContentType}`,
    )

    if (apiResponse.ok) {
      // Successful response from external API (2xx status code)
      if (responseContentType && responseContentType.includes("application/json")) {
        const data = await apiResponse.json()
        console.log(`Proxy: Successfully parsed JSON response from ${endpoint}`)
        return new Response(JSON.stringify(data), {
          status: apiResponse.status,
          headers: { "Content-Type": "application/json" },
        })
      } else {
        // Successful response, but not JSON (e.g., text/html, text/plain)
        // This might indicate an issue if JSON was expected.
        const textData = await apiResponse.text()
        console.warn(
          `Proxy: Response from ${endpoint} was ${apiResponse.status} (OK) but not JSON. Content-Type: ${responseContentType}. Body (first 200 chars): ${textData.substring(0, 200)}...`,
        )
        // Return a JSON object indicating this unexpected format, but still with original status.
        return new Response(
          JSON.stringify({
            warning: "Unexpected response format from external API, though request was successful.",
            details: `Expected application/json, got ${responseContentType}.`,
            responseText: textData,
            externalStatus: apiResponse.status,
          }),
          {
            status: apiResponse.status, // Pass through original status
            headers: { "Content-Type": "application/json" },
          },
        )
      }
    } else {
      // Error response from external API (4xx, 5xx status code)
      const errorText = await apiResponse.text() // Read error as text, as it's likely not JSON
      console.error(
        `Proxy: Error from external API (${endpoint}): ${apiResponse.status} ${apiResponse.statusText}. Body (first 500 chars): ${errorText.substring(0, 500)}...`,
      )
      // Return a JSON error object to the client.
      return new Response(
        JSON.stringify({
          error: `External API Error: ${apiResponse.status} ${apiResponse.statusText}`,
          details: errorText, // This contains the raw error message from the external API
          externalStatus: apiResponse.status,
        }),
        {
          status: apiResponse.status, // Use the external API's status code for our response
          headers: { "Content-Type": "application/json" },
        },
      )
    }
  } catch (error) {
    // Catch errors from req.json() or other issues within the proxy logic itself
    console.error(`Error in proxy route for endpoint ${endpoint}:`, error)
    let errorMessage = "Internal server error in proxy"
    if (error instanceof SyntaxError && error.message.includes("JSON")) {
      errorMessage = "Invalid JSON in request to proxy."
    } else if (error instanceof Error) {
      errorMessage = error.message
    }

    return new Response(
      JSON.stringify({
        error: "Proxy Internal Error",
        details: errorMessage,
        endpoint: endpoint,
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      },
    )
  }
}
