"use client"

import { Suspense, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import VisaOrderForm from "@/components/visa-order-form"
import LoadingIndicator from "@/components/loading-indicator"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle } from "lucide-react"
import {
  createTravellerOmantel,
  createIframeOrderVisaOmantel,
  generateReferenceNumber,
  ensureVendorKey,
} from "@/lib/api"
import { countriesWithCodes } from "@/lib/countries"

function VisaOrderContent() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submissionStatus, setSubmissionStatus] = useState<"idle" | "success" | "error">("idle")

  const destinationFullName = searchParams?.get("destination") || "Unknown Destination"
  const programName = searchParams?.get("programName") || "Unknown Program"
  const programId = searchParams?.get("programId") || ""
  const programFee = searchParams?.get("fee") || "0"
  const travelDate = searchParams?.get("travelDate") || new Date().toISOString().split("T")[0]

  const getCountryCode = (countryName: string): string => {
    const country = countriesWithCodes.find(
      (c) => c.name.toLowerCase() === countryName.toLowerCase() || c.code.toLowerCase() === countryName.toLowerCase(),
    )
    return country ? country.code : "XX"
  }

  const handleFormSubmit = async (formData: any, uploadedFiles: File[]) => {
    setIsLoading(true)
    setError(null)
    setSubmissionStatus("idle")

    if (!programId) {
      setError("Program ID is missing. Cannot proceed.")
      setIsLoading(false)
      setSubmissionStatus("error")
      return
    }

    let travellerResponse: any
    let currentVendorKey: string | null = null

    try {
      currentVendorKey = await ensureVendorKey()
      if (!currentVendorKey) {
        setError("Failed to obtain vendor key. Cannot proceed.")
        setIsLoading(false)
        setSubmissionStatus("error")
        return
      }
      console.log(`handleFormSubmit: Using vendorKey: ${currentVendorKey.substring(0, 10)}...`)

      const travellerData = {
        email: formData.email,
        first_name: formData.firstName,
        last_name: formData.lastName,
        locale: "en",
      }
      console.log("handleFormSubmit: Attempting to create traveller:", travellerData)
      travellerResponse = await createTravellerOmantel(travellerData)
      console.log("handleFormSubmit: Create Traveller Response:", travellerResponse)

      const travellerAccessToken = localStorage.getItem("traveller_access_token")

      let travellerCreationFailed = false
      let specificErrorMessage = ""

      if (!travellerResponse) {
        travellerCreationFailed = true
        specificErrorMessage = "No response from traveller creation service."
      } else if (travellerResponse.success === false && !travellerResponse._isMockData) {
        travellerCreationFailed = true
        specificErrorMessage =
          travellerResponse.error ||
          travellerResponse.details ||
          travellerResponse.message ||
          "Traveller creation API returned an error."
      } else if (!travellerAccessToken && !travellerResponse._isMockData) {
        travellerCreationFailed = true
        specificErrorMessage = "Traveller access token not found after creation."
        if (travellerResponse.message && travellerResponse.message !== "success") {
          specificErrorMessage += ` API Message: ${travellerResponse.message}`
        } else if (!travellerResponse.message && travellerResponse.result && travellerResponse.result.length === 0) {
          specificErrorMessage += ` API returned empty result.`
        }
      }

      if (travellerCreationFailed) {
        console.error(
          "handleFormSubmit: Traveller creation failed. Reason:",
          specificErrorMessage,
          "API Response:",
          travellerResponse,
        )
        setError(`Traveller creation failed: ${specificErrorMessage}`)
        setIsLoading(false)
        setSubmissionStatus("error")
        return
      }
      console.log("handleFormSubmit: Traveller created successfully and access token found (or using mock).")

      const referenceNo = generateReferenceNumber()
      const destinationCode = getCountryCode(destinationFullName)
      if (destinationCode === "XX") {
        console.warn(`Could not find country code for ${destinationFullName}. Using 'XX'. This might cause issues.`)
      }

      const iframeOrderData = {
        vendor_key: currentVendorKey,
        reference_no: referenceNo,
        description: `Visa application for ${programName} to ${destinationFullName}`,
        program_id: programId,
        quantity: 1,
        first_name: formData.firstName,
        last_name: formData.lastName,
        email: formData.email,
        fee: programFee,
        arrival: travelDate,
        destination: destinationCode,
      }

      console.log("handleFormSubmit: Attempting to create iframe order with data:", iframeOrderData)
      const iframeResponse = await createIframeOrderVisaOmantel(iframeOrderData)
      console.log("handleFormSubmit: Iframe Order Response:", iframeResponse)

      if (iframeResponse?.result?.iframe_deeplink_url && iframeResponse?.result?.order_id) {
        const iframeUrl = iframeResponse.result.iframe_deeplink_url
        const orderId = iframeResponse.result.order_id
        console.log(
          `handleFormSubmit: Iframe order successful. Navigating to /visa-confirmation with iframe_url and order_id: ${orderId}`,
        )
        localStorage.setItem("current_order_reference", referenceNo)
        localStorage.setItem("current_order_program_name", programName)
        localStorage.setItem("current_order_destination", destinationFullName)
        setSubmissionStatus("success")
        router.push(
          `/visa-confirmation?iframe_url=${encodeURIComponent(iframeUrl)}&order_id=${encodeURIComponent(orderId)}`,
        )
      } else {
        const errorMsg =
          iframeResponse?.error ||
          iframeResponse?.details ||
          iframeResponse?.message ||
          "Failed to create iframe order or missing iframe_deeplink_url/order_id."
        console.error("handleFormSubmit: Iframe order creation failed:", errorMsg, iframeResponse)
        setError(`Order creation failed: ${errorMsg}`)
        setSubmissionStatus("error")
      }
    } catch (apiError: any) {
      console.error("handleFormSubmit: API Error during submission process:", apiError)
      const message = apiError.message || "An unexpected error occurred during submission."
      setError(
        message.startsWith("Traveller creation failed:") ||
          message.startsWith("Order creation failed:") ||
          message.startsWith("Backend issue:")
          ? message
          : `Submission process error: ${message}`,
      )
      setSubmissionStatus("error")
    } finally {
      setIsLoading(false)
    }
  }

  if (!programId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4 text-center">
        <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-semibold text-gray-800 mb-2">Missing Information</h1>
        <p className="text-gray-600 mb-6">
          Essential visa program information is missing. Please go back and select a visa program again.
        </p>
        <Button onClick={() => router.push("/")} className="bg-[#ea6e00] hover:bg-[#ff7800] text-white">
          Go to Homepage
        </Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-gray-800">Visa Application</h1>
          <p className="text-lg text-gray-600 mt-2">
            You are applying for: <span className="font-semibold text-[#ea6e00]">{programName}</span> for{" "}
            <span className="font-semibold text-[#ea6e00]">{destinationFullName}</span>.
          </p>
        </div>

        {isLoading && (
          <div className="my-6">
            <LoadingIndicator text="Submitting your application, please wait..." />
          </div>
        )}

        {submissionStatus === "error" && error && (
          <div
            className="my-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-start"
            role="alert"
          >
            <AlertCircle className="h-5 w-5 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Submission Failed</p>
              <p className="text-sm">{error}</p>
            </div>
          </div>
        )}

        {submissionStatus === "success" && (
          <div
            className="my-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg flex items-start"
            role="alert"
          >
            <CheckCircle className="h-5 w-5 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Submission Successful!</p>
              <p className="text-sm">Redirecting you to complete your visa application...</p>
            </div>
          </div>
        )}

        {!isLoading && submissionStatus !== "success" && (
          <VisaOrderForm
            orderNumber={1}
            destination={destinationFullName}
            programName={programName}
            onSubmit={handleFormSubmit}
            initialStatus={submissionStatus === "error" ? "pending" : "pending"}
          />
        )}
      </div>
    </div>
  )
}

export default function VisaOrderPage() {
  return (
    <Suspense fallback={<LoadingIndicator text="Loading visa order details..." />}>
      <VisaOrderContent />
    </Suspense>
  )
}
