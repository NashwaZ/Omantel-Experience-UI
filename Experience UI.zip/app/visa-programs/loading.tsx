import LoadingIndicator from "@/components/loading-indicator"

export default function Loading() {
  return <LoadingIndicator fullScreen text="Loading visa programs..." size="large" />
}
