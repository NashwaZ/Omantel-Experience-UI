export default function VisaResultsLoading() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center">
      {/* Loading Indicator */}
      <div className="flex flex-col items-center">
        <div
          className="w-16 h-16 rounded-xl overflow-hidden shadow-lg flex items-center justify-center"
          style={{ backgroundColor: "#b55500" }} // Custom background color for the icon
        >
          <div className="flex space-x-1.5 rtl:space-x-reverse items-center justify-center h-full">
            <div
              className="w-3 h-3 bg-white rounded-full animate-bounce" // Dots are white
              style={{ animationDelay: "0ms", animationDuration: "0.7s" }}
            />
            <div
              className="w-3 h-3 bg-white rounded-full animate-bounce" // Dots are white
              style={{ animationDelay: "200ms", animationDuration: "0.7s" }}
            />
            <div
              className="w-3 h-3 bg-white rounded-full animate-bounce" // Dots are white
              style={{ animationDelay: "400ms", animationDuration: "0.7s" }}
            />
          </div>
        </div>
        {/* Text removed as per request */}
      </div>
    </div>
  )
}
