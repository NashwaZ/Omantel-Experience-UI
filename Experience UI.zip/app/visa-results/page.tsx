"use client"

import { useEffect, useState, Suspense } from "react"
import { AlertCircle, CheckCircle2, Info, ArrowLeft, CalendarDays, BarChart3, Users, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import { getVisaPrograms } from "@/lib/api"
import { getCountryFlagUrl } from "@/lib/country-utils"
import VisaResultsLoading from "./loading" // This is the correct loading component for this page
import { useLanguage } from "@/contexts/language-context"

interface VisaProgram {
  id: string
  name: string
  description: string
  price: number
  currency: string
  feeOMR?: number
  processingTime: string
  imageUrl?: string
  countryCode?: string
  category?: string
  max_stay?: string
  validity?: string
  max_entries?: string | number
  available?: boolean
}

const VisaResultsPageContent = () => {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { t, language, dateLocale } = useLanguage()

  const [visaPrograms, setVisaPrograms] = useState<VisaProgram[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const destinationParam = searchParams?.get("destination")
  const citizenshipParam = searchParams?.get("citizenship")
  const travelDateParam = searchParams?.get("travelDate")

  const displayDestination = destinationParam || "N/A"
  const mainDestinationFlagUrl = getCountryFlagUrl(displayDestination, "512")

  useEffect(() => {
    if (!destinationParam || !citizenshipParam || !travelDateParam) {
      setError(t.missingSearchParams || "Essential search parameters are missing. Please start your search again.")
      setLoading(false)
      return
    }

    const fetchVisaPrograms = async () => {
      setLoading(true)
      setError(null)
      try {
        const params = { destination: destinationParam, citizenship: citizenshipParam, arrivalDate: travelDateParam }
        const response = await getVisaPrograms(params)

        if (response.success && response.data) {
          const transformedData = response.data.map((p: any) => ({
            ...p,
            feeOMR: p.feeOMR || (p.price && p.currency === "USD" ? p.price * 0.384 : undefined),
            max_stay: p.max_stay || "N/A",
            validity: p.validity || "N/A",
            max_entries: p.max_entries || "N/A",
            available: p.available !== undefined ? p.available : true,
          }))
          setVisaPrograms(transformedData)
        } else {
          setError(response.error || t.noVisaProgramsFound || "Failed to fetch visa programs.")
          setVisaPrograms([])
        }
      } catch (err) {
        console.error("Fetch error:", err)
        setError(err instanceof Error ? err.message : t.apiErrorDefault || "An unexpected error occurred.")
        setVisaPrograms([])
      } finally {
        setLoading(false)
      }
    }

    fetchVisaPrograms()
  }, [destinationParam, citizenshipParam, travelDateParam, t])

  const renderDetailRow = (label: string, value?: string | number | null) => {
    if (value === undefined || value === null || value === "") return null
    return (
      <div className="flex justify-between items-center py-2.5 text-sm border-b border-slate-200 last:border-b-0">
        <span className="text-slate-600">{label}:</span>
        <span className="font-medium text-slate-800 text-right">{String(value)}</span>
      </div>
    )
  }

  if (loading) return <VisaResultsLoading /> // Uses the specific loading component for this page layout
  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center flex flex-col items-center justify-center flex-grow min-h-screen bg-white">
        <AlertCircle className="mx-auto h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-2xl font-semibold text-red-700 mb-2">{t.errorOccurred || "An Error Occurred"}</h2>
        <p className="text-slate-600 mb-8">{error}</p>
        <Button
          onClick={() => router.push("/")}
          className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2.5 px-6 rounded-lg"
        >
          {t.backToHome || "Back to Search"}
        </Button>
      </div>
    )
  }

  const displayCitizenship = citizenshipParam || "N/A"
  const displayTravelDate = travelDateParam || ""

  return (
    <div className="min-h-screen bg-white text-slate-800">
      <div className="bg-white h-14 flex items-center px-4 sticky top-0 z-50">
        <Button
          variant="ghost"
          size="icon"
          className="text-orange-500 hover:text-orange-400"
          onClick={() => router.back()}
        >
          <ArrowLeft size={24} />
        </Button>
      </div>

      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg text-sm">
            <FileText size={16} className="text-orange-500" />
            <span className="font-medium text-slate-700">{displayCitizenship} Citizen</span>
          </div>
        </div>

        <h1 className="text-3xl md:text-4xl font-bold text-center mb-2">Visa Options for {displayDestination}</h1>
        <p className="text-slate-600 text-center text-md md:text-lg mb-8">
          Discover available visa programs for your trip to {displayDestination}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          {[
            {
              icon: CalendarDays,
              label: t.travelDateLabel || "Travel Date",
              value: (() => {
                if (!displayTravelDate) return "Invalid Date"
                const parts = displayTravelDate.split("-")
                if (parts.length === 3) {
                  const day = Number.parseInt(parts[0], 10)
                  const month = Number.parseInt(parts[1], 10) - 1
                  const year = Number.parseInt(parts[2], 10)
                  if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                    const dateObj = new Date(year, month, day)
                    if (dateObj.getFullYear() === year && dateObj.getMonth() === month && dateObj.getDate() === day) {
                      return dateObj.toLocaleDateString(dateLocale)
                    }
                  }
                }
                return "Invalid Date"
              })(),
            },
            { icon: BarChart3, label: t.destinationCountryLabel || "Destination", value: displayDestination },
            { icon: Users, label: t.citizenshipLabel || "Citizenship", value: displayCitizenship },
          ].map((item, index) => (
            <div key={index} className="bg-slate-100 p-4 rounded-xl flex items-center">
              <div className="bg-orange-100 p-2.5 rounded-full mr-4">
                <item.icon size={24} className="text-orange-500" />
              </div>
              <div>
                <p className="text-xs text-slate-500">{item.label}</p>
                <p className="font-semibold text-slate-700">{item.value}</p>
              </div>
            </div>
          ))}
        </div>

        {visaPrograms.length === 0 && !loading && !error && (
          <div className="text-center py-12">
            <Info className="mx-auto h-16 w-16 text-blue-500 mb-4" />
            <h2 className="text-2xl font-semibold text-slate-700 mb-2">
              {t.noVisaProgramsFound || "No Visa Programs Found"}
            </h2>
            <p className="text-slate-600 mb-8">
              {t.noVisaProgramsSubtitle || "We couldn't find any visa programs matching your criteria."}
            </p>
          </div>
        )}

        {visaPrograms.map((program) => {
          const imageSrcToUse =
            mainDestinationFlagUrl ||
            `/placeholder.svg?width=512&height=341&query=${encodeURIComponent(displayDestination + " flag")}`
          const isExternalOrPlaceholder =
            imageSrcToUse.startsWith("http") || imageSrcToUse.startsWith("/placeholder.svg")

          return (
            <div key={program.id} className="mb-10">
              {program.category && (
                <div className="flex justify-center mb-4">
                  <div className="inline-block bg-orange-500 text-white text-sm font-semibold px-4 py-2 rounded-lg shadow-md">
                    {program.category}
                  </div>
                </div>
              )}
              <Card className="shadow-xl rounded-2xl overflow-hidden border border-slate-200">
                <CardContent className="p-0 md:flex">
                  <div className="w-full aspect-[3/2] md:aspect-auto md:w-2/5 relative p-0 flex items-center justify-center bg-slate-50 md:border-r border-slate-200 overflow-hidden md:rounded-l-2xl rounded-t-2xl md:rounded-tr-none">
                    <Image
                      src={imageSrcToUse || "/placeholder.svg"}
                      alt={`${displayDestination} Flag`}
                      fill
                      className="md:rounded-l-2xl rounded-t-2xl md:rounded-tr-none object-contain"
                      priority={visaPrograms.indexOf(program) < 2}
                      unoptimized={isExternalOrPlaceholder}
                    />
                  </div>
                  <div className="md:w-3/5 p-6 md:p-8">
                    {program.available && (
                      <div className="flex justify-end mb-3">
                        <div className="inline-flex items-center gap-1.5 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                          <CheckCircle2 size={14} />
                          Available
                        </div>
                      </div>
                    )}
                    <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-6">{program.name}</h2>
                    {!program.available && (
                      <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-center">
                        <p className="text-sm text-red-700 font-medium">
                          {t.visaUnavailableDisclaimer ||
                            "This visa program is currently unavailable or does not meet the specified criteria."}
                        </p>
                      </div>
                    )}

                    <div className="bg-white border border-slate-200 rounded-xl p-4 mb-6">
                      <div className="flex items-center text-orange-600 font-semibold mb-3">
                        <Info size={18} className="mr-2" />
                        Visa Details
                      </div>
                      {renderDetailRow(
                        t.feeUSDLabel || "Fee (USD)",
                        program.currency === "USD"
                          ? `$${program.price.toFixed(2)}`
                          : `${program.price.toFixed(2)} ${program.currency}`,
                      )}
                      {program.feeOMR &&
                        renderDetailRow(t.feeOMRLabel || "Fee (OMR)", `${program.feeOMR.toFixed(3)} OMR`)}
                      {renderDetailRow(t.processingTime || "Processing", program.processingTime)}
                      {renderDetailRow(t.maxStay || "Max Stay", program.max_stay)}
                      {renderDetailRow(t.validity || "Validity", program.validity)}
                      {renderDetailRow(t.entries || "Entries", program.max_entries)}
                      {renderDetailRow(t.status || "Status", program.available ? "Available" : "Not Available")}
                    </div>

                    <Button
                      className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-lg text-base disabled:bg-slate-300 disabled:cursor-not-allowed"
                      onClick={() =>
                        router.push(
                          `/visa-orders?programId=${program.id}&destination=${displayDestination}&citizenship=${citizenshipParam || ""}&travelDate=${travelDateParam || ""}`,
                        )
                      }
                      disabled={!program.available}
                    >
                      {t.applyNow || "Apply Now"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )
        })}
      </main>
    </div>
  )
}

export default function VisaResultsPage() {
  return (
    <Suspense fallback={<VisaResultsLoading />}>
      <VisaResultsPageContent />
    </Suspense>
  )
}
