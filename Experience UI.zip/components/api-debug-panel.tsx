"use client"

// This component has been disabled
export default function ApiDebugPanel() {
  return null
}
