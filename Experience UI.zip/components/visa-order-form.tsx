"use client"

import type React from "react"
import { useState, useRef, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ChevronDown, ChevronUp, FileText, Info, XCircle, Paperclip } from "lucide-react"
import { getDestinationRequirements, type DestinationRequirement } from "@/lib/destination-requirements" // Ensure type is imported
import { Progress } from "@/components/ui/progress"

interface VisaOrderFormProps {
  orderNumber: number
  destination: string // Crucial: This must match a key in destination-requirements.ts (e.g., "USA")
  programName: string
  onSubmit: (formData: any, uploadedFiles: File[]) => void
  initialStatus?: "pending" | "submitted" | "approved" | "rejected"
}

export default function VisaOrderForm({
  orderNumber,
  destination,
  programName,
  onSubmit,
  initialStatus = "pending",
}: VisaOrderFormProps) {
  const [isExpanded, setIsExpanded] = useState(initialStatus === "pending")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
  })
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Memoize to avoid re-calculating on every render unless 'destination' changes
  const destinationReqs: DestinationRequirement | undefined = useMemo(() => {
    // console.log(`VisaOrderForm #${orderNumber}: Getting requirements for destination: "${destination}"`);
    return getDestinationRequirements(destination)
  }, [destination])

  const numberOfRequiredDocs: number = useMemo(() => {
    const num = destinationReqs?.requiredDocuments.length || 0
    // console.log(`VisaOrderForm #${orderNumber}: Number of required docs: ${num}`);
    return num
  }, [destinationReqs])

  useEffect(() => {
    if (initialStatus !== "pending") {
      setIsExpanded(false)
    }
  }, [initialStatus])

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const newFiles = Array.from(event.target.files)
      if (numberOfRequiredDocs > 0 && uploadedFiles.length + newFiles.length > numberOfRequiredDocs) {
        // alert(`You can upload a maximum of ${numberOfRequiredDocs} document(s) for ${destination}.`) // Removed this line
        const remainingSlots = numberOfRequiredDocs - uploadedFiles.length
        setUploadedFiles((prevFiles) => [...prevFiles, ...newFiles.slice(0, remainingSlots)])
      } else {
        setUploadedFiles((prevFiles) => [...prevFiles, ...newFiles])
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const removeFile = (fileName: string) => {
    setUploadedFiles((prevFiles) => prevFiles.filter((file) => file.name !== fileName))
  }

  const isPersonalInfoValid = formData.firstName && formData.lastName && formData.email && formData.phoneNumber
  const areDocumentsUploaded = numberOfRequiredDocs === 0 || uploadedFiles.length >= numberOfRequiredDocs
  const isReadyToSubmit = isPersonalInfoValid && areDocumentsUploaded && initialStatus === "pending"

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (isReadyToSubmit) {
      onSubmit(formData, uploadedFiles)
    }
  }

  const uploadProgress = numberOfRequiredDocs > 0 ? (uploadedFiles.length / numberOfRequiredDocs) * 100 : 100

  console.log("VisaOrderForm Debug:", {
    orderNumber,
    destination,
    isPersonalInfoValid,
    areDocumentsUploaded,
    numUploaded: uploadedFiles.length,
    numRequired: numberOfRequiredDocs,
    initialStatus,
    isReadyToSubmit,
    formDataFilled: formData.firstName && formData.lastName && formData.email && formData.phoneNumber,
  })

  // console.log(`VisaOrderForm #${orderNumber}: Destination Reqs Object:`, destinationReqs);
  // console.log(`VisaOrderForm #${orderNumber}: isReadyToSubmit: ${isReadyToSubmit}`);

  return (
    <div className="w-full max-w-4xl mx-auto mb-6">
      {/* Order Button (Toggle) */}
      <Button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full h-16 bg-[#ea6e00] hover:bg-[#ff7800] text-white text-xl font-semibold rounded-2xl flex items-center justify-between px-8 shadow-lg transition-all duration-300"
      >
        <div className="flex items-center">
          <span>Order #{orderNumber}</span>
          {initialStatus !== "pending" && (
            <span
              className={`ml-3 text-sm px-2 py-0.5 rounded-full ${
                initialStatus === "submitted"
                  ? "bg-blue-500"
                  : initialStatus === "approved"
                    ? "bg-green-500"
                    : initialStatus === "rejected"
                      ? "bg-red-500"
                      : "bg-gray-500"
              }`}
            >
              {initialStatus.charAt(0).toUpperCase() + initialStatus.slice(1)}
            </span>
          )}
        </div>
        {isExpanded ? <ChevronUp className="h-6 w-6" /> : <ChevronDown className="h-6 w-6" />}
      </Button>

      {/* Expanded Form Content */}
      {isExpanded && (
        <Card className="mt-4 shadow-lg border-0 rounded-2xl overflow-hidden">
          <CardHeader className="bg-gray-50 border-b">
            <CardTitle className="text-2xl text-gray-900 flex items-center">
              <FileText className="h-6 w-6 mr-3 text-[#ea6e00]" />
              Visa Application for {destination}
            </CardTitle>
            <p className="text-gray-600 mt-2">{programName}</p>
          </CardHeader>

          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information Section (Assumed to be working) */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                  <Info className="h-5 w-5 mr-2 text-[#ea6e00]" />
                  Personal Information
                </h3>
                {/* ... input fields ... */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor={`firstName-${orderNumber}`} className="text-sm font-medium text-gray-700">
                      First Name *
                    </Label>
                    <Input
                      id={`firstName-${orderNumber}`}
                      type="text"
                      placeholder="Enter your first name"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                      className="h-12 rounded-xl"
                      required
                      disabled={initialStatus !== "pending"}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`lastName-${orderNumber}`} className="text-sm font-medium text-gray-700">
                      Last Name *
                    </Label>
                    <Input
                      id={`lastName-${orderNumber}`}
                      type="text"
                      placeholder="Enter your last name"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                      className="h-12 rounded-xl"
                      required
                      disabled={initialStatus !== "pending"}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`email-${orderNumber}`} className="text-sm font-medium text-gray-700">
                      Email *
                    </Label>
                    <Input
                      id={`email-${orderNumber}`}
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="h-12 rounded-xl"
                      required
                      disabled={initialStatus !== "pending"}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`phoneNumber-${orderNumber}`} className="text-sm font-medium text-gray-700">
                      Phone No *
                    </Label>
                    <Input
                      id={`phoneNumber-${orderNumber}`}
                      type="tel"
                      placeholder="Enter your phone number"
                      value={formData.phoneNumber}
                      onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                      className="h-12 rounded-xl"
                      required
                      disabled={initialStatus !== "pending"}
                    />
                  </div>
                </div>
              </div>

              {/* ===== DOCUMENT REQUIREMENTS SECTION ===== */}
              {/* This entire block will only render if 'destinationReqs' is truthy (i.e., requirements were found) */}
              {destinationReqs ? (
                <div className="border-t pt-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                    <Paperclip className="h-5 w-5 mr-2 text-[#ea6e00]" />
                    Document Requirements for {destination}
                  </h3>

                  {/* Box displaying the requirements */}
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 space-y-4">
                    <div>
                      <h4 className="font-semibold text-amber-800 mb-2">
                        Required Documents to Upload ({numberOfRequiredDocs} file(s)):
                      </h4>
                      {/* This list renders if numberOfRequiredDocs > 0 */}
                      {numberOfRequiredDocs > 0 && destinationReqs.requiredDocuments ? (
                        <ul className="list-disc list-inside space-y-1 text-amber-700">
                          {destinationReqs.requiredDocuments.map((doc, index) => (
                            <li key={index}>{doc}</li> // For USA, this should show "Passport Photo"
                          ))}
                        </ul>
                      ) : (
                        <p className="text-amber-700">
                          No specific documents need to be uploaded for this destination through our system.
                        </p>
                      )}
                    </div>

                    {/* This section renders if additionalInformation exists */}
                    {destinationReqs.additionalInformation && (
                      <div>
                        <h4 className="font-semibold text-amber-800 mb-2">Additional Information & Guidelines:</h4>
                        <p className="text-amber-700 text-sm leading-relaxed">
                          {destinationReqs.additionalInformation} {/* For USA, this shows passport validity */}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* ===== FILE UPLOAD CONTAINER ===== */}
                  {/* This section renders if the order is pending and there are documents to upload */}
                  {initialStatus === "pending" && numberOfRequiredDocs > 0 && (
                    <div className="mt-6">
                      <h4 className="font-semibold text-gray-800 mb-3">Upload Your Documents:</h4>
                      <div className="mb-4">
                        {/* The "ADD FILE" button */}
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="add-file-btn" // Ensure CSS for this class is loaded from globals.css
                          disabled={
                            (uploadedFiles.length >= numberOfRequiredDocs && numberOfRequiredDocs > 0) ||
                            initialStatus !== "pending"
                          }
                        >
                          <svg
                            aria-hidden="true"
                            stroke="currentColor"
                            strokeWidth="2"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeWidth="2"
                              stroke="#fffffff"
                              d="M13.5 3H12H8C6.34315 3 5 4.34315 5 6V18C5 19.6569 6.34315 21 8 21H11M13.5 3L19 8.625M13.5 3V7.625C13.5 8.17728 13.9477 8.625 14.5 8.625H19M19 8.625V11.8125"
                              strokeLinejoin="round"
                              strokeLinecap="round"
                            ></path>
                            <path
                              strokeLinejoin="round"
                              strokeLinecap="round"
                              strokeWidth="2"
                              stroke="#fffffff"
                              d="M17 15V18M17 21V18M17 18H14M17 18H20"
                            ></path>
                          </svg>
                          ADD FILE ({uploadedFiles.length}/{numberOfRequiredDocs})
                        </button>
                        <input
                          type="file"
                          multiple
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          className="hidden"
                          accept="image/*,.pdf,.doc,.docx"
                        />
                      </div>

                      {/* List of uploaded files */}
                      {uploadedFiles.length > 0 && (
                        <div className="space-y-3 mb-4">
                          <p className="text-sm font-medium text-gray-700">Uploaded files:</p>
                          {uploadedFiles.map((file, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-3 bg-gray-100 rounded-lg text-sm"
                            >
                              <span className="truncate text-gray-700">
                                {file.name} ({(file.size / 1024).toFixed(1)} KB)
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeFile(file.name)}
                                className="text-red-500 hover:text-red-700 p-1 h-auto"
                                disabled={initialStatus !== "pending"}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                      {/* Upload Progress Bar */}
                      {numberOfRequiredDocs > 0 && (
                        <div className="mt-2">
                          <Progress value={uploadProgress} className="w-full h-2 [&>div]:bg-[#ea6e00]" />
                          <p className="text-xs text-gray-500 mt-1 text-right">
                            {uploadedFiles.length} of {numberOfRequiredDocs} files uploaded
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                // This message appears if no requirements are found for the 'destination'
                <div className="border-t pt-8">
                  <p className="text-center text-gray-600">
                    Document requirements for "{destination}" are not available or could not be loaded. Please ensure
                    the destination is correctly specified.
                  </p>
                </div>
              )}

              {/* Submit Button Section */}
              {initialStatus === "pending" && (
                <div className="flex justify-end pt-6 border-t">
                  <Button
                    type="submit"
                    disabled={!isReadyToSubmit} // This is key for enabling/disabling
                    className={`px-8 py-3 rounded-xl text-white font-semibold transition-all duration-300 ${
                      isReadyToSubmit ? "bg-[#ea6e00] hover:bg-[#ff7800] shadow-lg" : "bg-gray-400 cursor-not-allowed"
                    }`}
                  >
                    Submit Application
                  </Button>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
