"use client"

import type React from "react" // Changed import
import { useState, useEffect, useRef, useCallback } from "react"

interface DocumentUploadProps {
  destination: string
  onUploadComplete: (isComplete: boolean) => void
}

interface DocumentRequirement {
  name: string
  required: boolean
}

interface CountryRequirements {
  [country: string]: {
    documents: DocumentRequirement[]
    additionalInfo?: string
  }
}

export const DocumentUpload = ({ destination, onUploadComplete }: DocumentUploadProps) => {
  const [uploadedDocuments, setUploadedDocuments] = useState<{ [key: string]: File | null }>({})
  const [uploadProgress, setUploadProgress] = useState(0)
  const [requirements, setRequirements] = useState<DocumentRequirement[]>([])
  const [additionalInfo, setAdditionalInfo] = useState<string>("")
  const [dragActive, setDragActive] = useState<string | null>(null)

  const prevProgressRef = useRef<number>(0)

  const countryRequirements: CountryRequirements = {
    Australia: {
      documents: [{ name: "Passport Photo", required: true }],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). Additional documents requested in some cases, determined by the authorities/place of birth.",
    },
    "Australia eta": {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo 1", required: true },
        { name: "Portrait Photo 2", required: true },
        { name: "Portrait Photo 3", required: true },
      ],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). Three portrait photos need to be taken one after another, without smiling.",
    },
    Azerbaijan: {
      documents: [{ name: "Passport Photo", required: true }],
      additionalInfo: "Passport Requirements (3 months from visa expiry).",
    },
    Cambodia: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Return Ticket", required: false },
        { name: "Letter of Invitation", required: false },
        { name: "Hotel Reservation", required: false },
      ],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). Portrait Photo must be JPEG/JPG/PNG format.",
    },
    Canada: {
      documents: [],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Cuba: {
      documents: [{ name: "Passport Photo", required: true }],
    },
    Egypt: {
      documents: [{ name: "Passport Photo", required: true }],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Ethiopia: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
      ],
      additionalInfo: "Portrait photo should be recent with good quality not older than 6 months.",
    },
    India: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
      ],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Indonesia: {
      documents: [
        { name: "Passport Photo (JPG)", required: true },
        { name: "Passport Photo (PDF)", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Return Ticket (PDF)", required: true },
      ],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). Return Ticket must be in PDF format, no screenshots allowed.",
    },
    "Ivory Coast": {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Return Ticket", required: true },
        { name: "Hotel Reservation/Invitation Letter", required: true },
      ],
      additionalInfo:
        "All documents must be in JPG/PNG/GIF/PDF format, and each file should be ≤ 1 Mb. Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Jordan: {
      documents: [{ name: "Passport Photo", required: true }],
    },
    Kenya: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Accommodation Booking", required: true },
        { name: "Return Ticket", required: true },
        { name: "Invitation Letter (if applicable)", required: false },
        { name: "Host ID (if applicable)", required: false },
      ],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). In cases where the host is a resident of Kenya, the invitation letter and host ID are required.",
    },
    Korea: {
      documents: [{ name: "Portrait Photo", required: true }],
    },
    Kuwait: {
      documents: [{ name: "Passport Photo", required: true }],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Laos: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
      ],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Madagascar: {
      documents: [],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Myanmar: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Return Ticket", required: true },
        { name: "Hotel Booking Confirmation", required: true },
      ],
      additionalInfo:
        "Only passports will be eligible for e-visa. Travel documents will not be accepted. Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Malaysia: {
      documents: [
        { name: "Portrait Photo", required: true },
        { name: "Round Trip Flight Ticket", required: true },
        { name: "Accommodation Documents", required: true },
        { name: "Bank Statement", required: true },
      ],
      additionalInfo:
        "Portrait photo should be recent with good quality not older than 6 months. Bank statement must be within 3 months.",
    },
    "New Zealand": {
      documents: [{ name: "Portrait Photo", required: true }],
      additionalInfo:
        "Portrait photo should be recent with good quality not older than 6 months. Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Oman: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
      ],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Pakistan: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Letter By Sponsor/Hotel", required: true },
        { name: "Parent Consent Form (if under 18)", required: false },
      ],
      additionalInfo:
        "It is Mandatory to provide Parent Consent Form Visa for the applications of children under 18 Years of Age bearing passport of United States of America, United Kingdom and Australia. Passport Requirements (6 months of validity left from entry before its expiration date). Portrait photo should be recent with good quality not older than 6 months.",
    },
    Russia: {
      documents: [{ name: "Portrait Photo", required: true }],
      additionalInfo: "Portrait photo should be recent with good quality not older than 6 months.",
    },
    "Saudi Arabia": {
      documents: [{ name: "Portrait Photo", required: true }],
      additionalInfo: "Portrait photo should be recent with good quality not older than 6 months.",
    },
    Singapore: {
      documents: [],
    },
    "Sri Lanka": {
      documents: [],
    },
    Tanzania: {
      documents: [
        { name: "Portrait Photo", required: true },
        { name: "Passport Photo", required: true },
        { name: "Return Ticket", required: true },
      ],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Thailand: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
        { name: "Travel Booking Confirmation", required: true },
        { name: "Proof of Accommodation", required: true },
        { name: "Financial Evidence", required: true },
        { name: "Document Indicating Current Residency", required: true },
      ],
      additionalInfo:
        "Portrait photo should be recent with good quality not older than 6 months. Passport/travel document that is valid for at least six months from the date of visa application for single entry and one year for multiple entry. Financial evidence: amount of not less than 20,000 THB, e.g. bank statements, sponsorship letter.",
    },
    Turkey: {
      documents: [],
    },
    USA: {
      documents: [{ name: "Passport Photo", required: true }],
      additionalInfo: "Passport Requirements (6 months of validity left from entry before its expiration date).",
    },
    Vietnam: {
      documents: [
        { name: "Passport Photo", required: true },
        { name: "Portrait Photo", required: true },
      ],
      additionalInfo:
        "Passport Requirements (6 months of validity left from entry before its expiration date). Portrait photo should be recent with good quality not older than 6 months.",
    },
  }

  const findClosestCountry = useCallback((searchCountry: string): string => {
    if (countryRequirements[searchCountry]) {
      return searchCountry
    }
    const lowerSearchCountry = searchCountry.toLowerCase()
    for (const country of Object.keys(countryRequirements)) {
      if (country.toLowerCase() === lowerSearchCountry) {
        return country
      }
    }
    for (const country of Object.keys(countryRequirements)) {
      if (country.toLowerCase().includes(lowerSearchCountry) || lowerSearchCountry.includes(country.toLowerCase())) {
        return country
      }
    }
    return ""
  }, []) // countryRequirements is stable

  useEffect(() => {
    const closestCountry = findClosestCountry(destination)
    if (closestCountry && countryRequirements[closestCountry]) {
      setRequirements(countryRequirements[closestCountry].documents)
      setAdditionalInfo(countryRequirements[closestCountry].additionalInfo || "")
      const initialUploadState: { [key: string]: File | null } = {}
      countryRequirements[closestCountry].documents.forEach((doc) => {
        initialUploadState[doc.name] = null
      })
      setUploadedDocuments(initialUploadState)
    } else {
      setRequirements([])
      setAdditionalInfo("")
      setUploadedDocuments({})
    }
  }, [destination, findClosestCountry]) // countryRequirements is stable, so not needed here

  useEffect(() => {
    const requiredDocs = requirements.filter((doc) => doc.required)
    if (requiredDocs.length === 0) {
      setUploadProgress(100)
      if (prevProgressRef.current !== 100) {
        onUploadComplete(true) // Added onUploadComplete to dependencies
        prevProgressRef.current = 100
      }
      return
    }
    const uploadedRequiredDocs = requiredDocs.filter((doc) => uploadedDocuments[doc.name] !== null)
    const progress = Math.round((uploadedRequiredDocs.length / requiredDocs.length) * 100)
    setUploadProgress(progress)
    if (prevProgressRef.current !== progress) {
      onUploadComplete(progress === 100) // Added onUploadComplete to dependencies
      prevProgressRef.current = progress
    }
  }, [uploadedDocuments, requirements, onUploadComplete]) // Added onUploadComplete

  const handleFileUpload = (documentName: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setUploadedDocuments((prev) => ({ ...prev, [documentName]: file }))
      localStorage.setItem(`document_${documentName.replace(/\s+/g, "_")}`, file.name)
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>, documentName: string) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(documentName)
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(null)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, documentName: string) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(null)
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0]
      setUploadedDocuments((prev) => ({ ...prev, [documentName]: file }))
      localStorage.setItem(`document_${documentName.replace(/\s+/g, "_")}`, file.name)
    }
  }

  const removeUploadedFile = (documentName: string) => {
    setUploadedDocuments((prev) => ({ ...prev, [documentName]: null }))
    localStorage.removeItem(`document_${documentName.replace(/\s+/g, "_")}`)
  }

  const getProgressColor = (progress: number) => {
    if (progress < 33) return "bg-red-500"
    if (progress < 66) return "bg-orange-500"
    if (progress < 100) return "bg-yellow-500"
    return "bg-green-500"
  }

  if (requirements.length === 0) {
    return null
  }

  return (
    <div className="w-full max-w-xs p-4 border border-gray-200 rounded-xl">
      <h4 className="font-semibold text-gray-900 mb-3 text-center flex items-center justify-center">
        <svg className="w-4 h-4 mr-1 text-[#ea6e00]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
          />
        </svg>
        Required Documents
      </h4>
      {additionalInfo && <p className="caption text-gray-600 mb-3 text-center">{additionalInfo}</p>}
      <div className="space-y-3 mb-3">
        {requirements.map((doc) => (
          <div key={doc.name}>
            <label htmlFor={doc.name.replace(/\s+/g, "-")} className="block caption font-medium text-gray-700 mb-1">
              {doc.name} {doc.required && <span className="text-red-500">*</span>}
            </label>
            <div
              onDragOver={(e) => handleDragOver(e, doc.name)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, doc.name)}
              className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${dragActive === doc.name ? "border-[#ea6e00]" : "border-gray-300"} border-dashed rounded-md transition-colors`}
            >
              <div className="space-y-1 text-center">
                {uploadedDocuments[doc.name] ? (
                  <div>
                    <svg
                      className="mx-auto h-10 w-10 text-green-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <p className="body-small text-gray-700 truncate max-w-[calc(100%-2rem)]">
                      {" "}
                      {/* Ensure text fits */}
                      {uploadedDocuments[doc.name]?.name}
                    </p>
                    <button
                      type="button"
                      onClick={() => removeUploadedFile(doc.name)}
                      className="caption text-red-600 hover:text-red-800"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <>
                    <svg
                      className="mx-auto h-10 w-10 text-gray-400"
                      stroke="currentColor"
                      fill="none"
                      viewBox="0 0 48 48"
                      aria-hidden="true"
                    >
                      <path
                        d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <div className="flex caption text-gray-600">
                      <label
                        htmlFor={doc.name.replace(/\s+/g, "-")}
                        className="relative cursor-pointer bg-white rounded-md font-medium text-[#ea6e00] hover:text-[#ff7800] focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-[#ea6e00]"
                      >
                        <span>Upload a file</span>
                        <input
                          id={doc.name.replace(/\s+/g, "-")}
                          name={doc.name.replace(/\s+/g, "-")}
                          type="file"
                          className="sr-only"
                          onChange={(e) => handleFileUpload(doc.name, e)}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, PDF up to 10MB</p>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      {requirements.some((doc) => doc.required) && (
        <div>
          <div className="flex justify-between caption text-gray-600 mb-1">
            <span>Progress</span>
            <span>{uploadProgress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ease-in-out ${getProgressColor(uploadProgress)}`}
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </div>
      )}
    </div>
  )
}
